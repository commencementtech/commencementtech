package com.scriptsbundle.nokri.employeer.jobs.fragments.SavedResumes;

public class SavedResumeModel {
    public String name;
    public String id;
    public String url;
    public String attachmentUrl;
}
