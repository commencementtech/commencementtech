package com.scriptsbundle.nokri.RichEditor.styles.toolitems;

public interface IARE_ToolItem_Updater {

    void onCheckStatusUpdate(boolean checked);
}
