package com.scriptsbundle.nokri.RichEditor.spans;

import android.text.style.UnderlineSpan;

public class AreUnderlineSpan extends UnderlineSpan {

}
