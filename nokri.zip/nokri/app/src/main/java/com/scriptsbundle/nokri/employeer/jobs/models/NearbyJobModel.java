package com.scriptsbundle.nokri.employeer.jobs.models;

public class NearbyJobModel {
    public int job_id;
    public String job_title;
    public String comp_name;
    public String comp_img;
    public String distance;
}
