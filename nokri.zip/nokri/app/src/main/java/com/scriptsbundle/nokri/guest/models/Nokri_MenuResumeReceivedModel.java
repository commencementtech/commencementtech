package com.scriptsbundle.nokri.guest.models;

public class Nokri_MenuResumeReceivedModel {
    private String takeAction;
    private String download;
    private String viewProfile;
    private String linkedin;
    private String delete;


    public String getDelete() {
        return delete;
    }

    public void setDelete(String delete) {
        this.delete = delete;
    }



    public String getTakeAction() {
        return takeAction;
    }

    public void setTakeAction(String takeAction) {
        this.takeAction = takeAction;
    }

    public String getDownload() {
        return download;
    }

    public void setDownload(String download) {
        this.download = download;
    }

    public String getViewProfile() {
        return viewProfile;
    }

    public void setViewProfile(String viewProfile) {
        this.viewProfile = viewProfile;
    }

    public String getLinkedin() {
        return linkedin;
    }

    public void setLinkedin(String linkedin) {
        this.linkedin = linkedin;
    }
}
