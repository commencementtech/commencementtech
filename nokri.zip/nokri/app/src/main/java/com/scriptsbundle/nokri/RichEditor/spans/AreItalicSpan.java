package com.scriptsbundle.nokri.RichEditor.spans;

import android.graphics.Typeface;
import android.text.style.StyleSpan;

/**
 * Created by wliu on 2018/1/19.
 */

public class AreItalicSpan extends StyleSpan {

    public AreItalicSpan() {
        super(Typeface.ITALIC);
    }
}
