package com.scriptsbundle.nokri.custom;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.Nullable;
import com.google.android.material.tabs.TabLayout;
import androidx.viewpager.widget.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.animation.DecelerateInterpolator;
import android.widget.Scroller;

import com.google.android.material.tabs.TabLayout;

import java.lang.reflect.Field;

/**
 * Created by Glixen Technologies on 29/01/2018.
 */

public class TabLayoutNoAutoScroll extends TabLayout {
    public TabLayoutNoAutoScroll(@NonNull Context context) {
        super(context);
        setMyScroller();
        setClickable(false);
        setEnabled(false);

    }

    public TabLayoutNoAutoScroll(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
      //  setMyScroller();
    }


    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        // Never allow swiping to switch between pages
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // Never allow swiping to switch between pages
        return false;
    }
    private void setMyScroller() {
        try {
            Class<?> viewpager = ViewPager.class;
            Field scroller = viewpager.getDeclaredField("mScroller");
            scroller.setAccessible(true);
            scroller.set(this, new MyScroller(getContext()));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }



    public class MyScroller extends Scroller {
        public MyScroller(Context context) {
            super(context, new DecelerateInterpolator());
        }

        @Override
        public void startScroll(int startX, int startY, int dx, int dy, int duration) {
            super.startScroll(startX, startY, dx, dy, 350 /*1 secs*/);
        }
    }

}
