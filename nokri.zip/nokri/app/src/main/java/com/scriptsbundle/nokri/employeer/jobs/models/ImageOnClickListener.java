package com.scriptsbundle.nokri.employeer.jobs.models;

import android.view.View;

public interface ImageOnClickListener {

        void onItemClick(AttachmentModel item);

        void delViewOnClick(View v, int position);

        void editViewOnClick(View v, int position);

    }

