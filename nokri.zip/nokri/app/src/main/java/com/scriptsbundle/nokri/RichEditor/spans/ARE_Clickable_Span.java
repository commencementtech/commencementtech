package com.scriptsbundle.nokri.RichEditor.spans;

/**
 * Created by wliu on 30/06/2018.
 */

public interface ARE_Clickable_Span {
}
