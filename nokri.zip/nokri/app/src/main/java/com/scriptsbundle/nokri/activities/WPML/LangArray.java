package com.scriptsbundle.nokri.activities.WPML;

public class LangArray{
    public String nativeName;
    public String langCode;
    public String flagUrl;
}
