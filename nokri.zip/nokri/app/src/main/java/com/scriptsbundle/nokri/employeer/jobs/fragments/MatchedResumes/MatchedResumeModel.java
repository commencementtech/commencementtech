package com.scriptsbundle.nokri.employeer.jobs.fragments.MatchedResumes;

public class MatchedResumeModel {
    public String id;
    public String name;
    public String expiryLabel;
    public String expiryValue;
    public String jobPostDateLabel;
    public String jobPostDateValue;
    public String jobStatus;
    public String viewResumeLabel;

}
