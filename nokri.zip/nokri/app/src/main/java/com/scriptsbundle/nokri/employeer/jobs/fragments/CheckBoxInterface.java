package com.scriptsbundle.nokri.employeer.jobs.fragments;

public interface CheckBoxInterface {
    public void onCheckClick(int position);
    public void onCheckUnClick(int position);
}
