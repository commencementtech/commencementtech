package com.scriptsbundle.nokri.Provider;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}