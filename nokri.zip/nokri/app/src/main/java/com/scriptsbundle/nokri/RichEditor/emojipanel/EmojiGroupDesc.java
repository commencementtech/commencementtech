package com.scriptsbundle.nokri.RichEditor.emojipanel;

import java.io.Serializable;

public class EmojiGroupDesc implements Serializable {
    public int numColumns;
    public int[] imageResIds;
    public int size = 30;
    public int padding = 5;
}