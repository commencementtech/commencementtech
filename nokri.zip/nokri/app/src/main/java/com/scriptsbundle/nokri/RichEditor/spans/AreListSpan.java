package com.scriptsbundle.nokri.RichEditor.spans;

import android.text.style.LeadingMarginSpan;

public interface AreListSpan extends LeadingMarginSpan {

}
