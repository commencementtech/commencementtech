package com.scriptsbundle.nokri.candidate.jobs.models;

public class JobAlertsModel {
    public String id;
    public String category;
    public String name;
    public String frequency;
}
