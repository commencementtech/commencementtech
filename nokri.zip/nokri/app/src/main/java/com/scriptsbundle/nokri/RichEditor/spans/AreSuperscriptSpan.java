package com.scriptsbundle.nokri.RichEditor.spans;

import android.text.style.SuperscriptSpan;

/**
 * Created by wliu on 2018/4/3.
 */

public class AreSuperscriptSpan extends SuperscriptSpan {
}
