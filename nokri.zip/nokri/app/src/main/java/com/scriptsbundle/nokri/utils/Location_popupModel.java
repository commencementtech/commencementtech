package com.scriptsbundle.nokri.utils;

public class Location_popupModel {
    private int slider_number, slider_step;
    private String location, text, btn_submit, btn_clear;

    public int getSlider_number() {
        return slider_number;
    }

    public void setSlider_number(int slider_number) {
        this.slider_number = slider_number;
    }

    public int getSlider_step() {
        return slider_step;
    }

    public void setSlider_step(int slider_step) {
        this.slider_step = slider_step;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getBtn_submit() {
        return btn_submit;
    }

    public void setBtn_submit(String btn_submit) {
        this.btn_submit = btn_submit;
    }

    public String getBtn_clear() {
        return btn_clear;
    }

    public void setBtn_clear(String btn_clear) {
        this.btn_clear = btn_clear;
    }
}

